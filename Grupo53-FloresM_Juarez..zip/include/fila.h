#ifndef FILA_H
#define FILA_H


class fila
{
    public:
        fila();
        virtual ~fila();

    protected:

    private:
};

#endif // FILA_H
