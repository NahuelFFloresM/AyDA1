#ifndef FILA_CPP_H
#define FILA_CPP_H


class fila.cpp
{
    public:
        fila.cpp();
        virtual ~fila.cpp();

    protected:

    private:
};

#endif // FILA_CPP_H
